<?php 
 $con=new mysqli('localhost','root','','shopping_cart'); 
 $name = $_POST['name'];
 $email = $_POST['email'];
 $mobile = $_POST['mobino']; 
 $password=$_POST['pass'];
$sql="select * from users where (name='$name' and emailid='$email');";

      $res=mysqli_query($con,$sql);

      if (mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);
      if($email==$row['emailid'] && $name==$row['name'])
        {
            echo "Email already exists";
			echo "<a href='index1.html'>Back</a>";
        }

       }
	   else
	   {
		   $query = "INSERT INTO users(name,mobileno,emailid,password)VALUES('$name','$mobile','$email','$password')";
 $result = mysqli_query($con,$query); 
		   echo "Account Created Successfully";
		   $sql = "CREATE TABLE $name (
sino INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
modalname VARCHAR(30) NOT NULL,
modelid VARCHAR(30) NOT NULL,
discr VARCHAR(50),quant INT(6)  DEFAULT '1',
price INT(6)
)";

if (mysqli_query($con, $sql)) {
    echo "Table $name created successfully";
} else {
    echo "Error creating table: " . mysqli_error($con);
}
		   echo "<a href='index1.html'>Login to continue...</a>";
	   }
?>
<?php 
session_start();
$username=$_SESSION["name"];
 $con=new mysqli('localhost','root','','shopping_cart');
$total=0; 
 $result = mysqli_query($con,"SELECT * FROM $username");
echo "<center><h1>MY CART</h1></center>";
echo "<table border='1'>
<tr>
<th>SI.no</th>
<th>ModName</th>
<th>Modid</th>
<th>Description</th>
<th>quantity</th>
<th>price</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['sino'] . "</td>";
echo "<td>" . $row['modalname'] . "</td>";
echo "<td>" . $row['modelid'] . "</td>";
echo "<td>" . $row['discr'] . "</td>";
echo "<td>" . $row['quant'] . "</td>";
echo "<td>" . $row['price'] . "</td>";
$total=$total+$row['price'];

echo "</tr>";
}

echo "</table>";
echo "<h1>total: $total</h1>";
echo "<form action='orderplaced.html' method='post'>";
echo "<center><input type='submit' value='PlaceOrder'>";
echo "<h3><a href='men.html'>Back</a></h3></center></form>";

?>
<?php 
session_start();
 $con=new mysqli('localhost','root','','shopping_cart'); 
 $name = $_POST['name'];
 $password=$_POST['pass'];
 $sql="select * from users where (name='$name' and password='$password');";
      $res=mysqli_query($con,$sql);

      if (mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);
      if($name==$row['name'] && $password==$row['password'])
        {
          $_SESSION["name"]=$row['name'];
            header("Location: gallery.php");
        }
       }
	   else
		{
			echo "<script>windows.alert('incorect')";
			
		}
?>
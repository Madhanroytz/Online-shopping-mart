<?php 
session_start();
$username=$_SESSION["name"];
 $con=new mysqli('localhost','root','','shopping_cart'); 
 $name = $_POST['b1'];
 $sql="select * from stock_detail where productID='$name';";
 $result = mysqli_query($con,$sql);
 $row = mysqli_fetch_array($result);
 $sql1="select quant from stock_detail where productID='$name';";
 $result1= mysqli_query($con,$sql);
 $row1 = mysqli_fetch_array($result1);
 $qt=$row['quant'];
 $temp=$qt-1;
 $query ="UPDATE stock_detail SET quant='$temp' WHERE prductID='$name';";
  mysqli_query($con,$query); 
 if($qt>0)
 {
 $mna=$row['productName'] ;
 $mno=$row['productID'];
 $des=$row['descr'];
 $p=$row['price'];
 $query = "INSERT INTO $username(modalname,modelid,discr,price)VALUES('$mna','$mno','$des','$p');";
 $result = mysqli_query($con,$query); 
 
 if($result)
 {
	 header("Location: display.php");
 }
 }
 else
 {
	 echo"<marquee><h1>no stock</h1></marquee>";
 }
 ?>
	
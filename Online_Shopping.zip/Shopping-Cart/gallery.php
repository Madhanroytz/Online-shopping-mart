<?php
session_start();
if(!isset($_SESSION["name"]))
{
  header("location:index1.html?mes=<p>please login here</p>");
}
?>
<html>
<head>
<style>
div.gallery {
    margin: 5px;
    border: 1px solid #ccc;
    float: left;
    width: 430px;
}

div.gallery:hover {
    border: 1px solid #777;
}

div.gallery img {
    width: 100%;
    height: 45%;
}

div.desc {
    padding: 15px;
    text-align:left;
}



<!DOCTYPE html>
<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: white;
}

li {
  float: left;
}

li a {
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover {
  background-color: sky blue;
}

</style>
</head>
<body>
<p><img src="logoo.png" align="left" height="110" width="100"/>
<div><ul>
<p align="center">
  <li><a><h1>hi <?php echo $_SESSION["name"];?></h1></a></li>
  <li><a href="about.html" >ABOUT</a></li>
  <li><a href="contact.html">CONTACT</a></li>
  <li><a href="logout.php">LOG OUT</a></li>
</p>
</ul></div>
<br>
<div class="gallery">
    <img src="p1.jpg" width="50" height="50">
  </a>
<a href="men.html">
  <div class="desc">MEN'S</div>
</a>
</div>

<div class="gallery">
    <img src="p2.jpg" width="50" height="50">
  </a>
<a href="women.html">
  <div class="desc">WOMEN'S</div>
</a>
</div>

<div class="gallery">
    <img src="p3.jpg" width="50" height="50">
  </a>
<a href="glossory.html">
  <div class="desc">GLOSSARY</div>
</a>
</div>

<div class="gallery">
    <img src="p4.jpg"  width="50" height="50">
  </a>
<a href="children.html">
  <div class="desc">CHILDREN</div>
</a>
</div>
<div class="gallery">
    <img src="p5.jfif" width="50" height="50">
  </a>
<a href="furniture.html">
  <div class="desc">FURNITURE'S</div>
</a>
</div>
<div class="gallery">
    <img src="e2.jpg" width="50" height="50">
  </a>
<a href="electronic.html">
  <div class="desc">ELECTRONICS AND APPLIANCES</div>
</a>
</div>

</body>
</html>